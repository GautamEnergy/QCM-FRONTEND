class DBConst {
  static final directory = 'directory';
  static final rmbDropDown = 'rmbDropDown';
  static final dashbordresbody1 = 'dashbordresbody1';
  static final dashbordresbody2 = 'dashbordresbody2';
  static final dashbordtopgivers = 'dashbordtopgivers';
  static final dashbordgetalert = 'dashbordgetalert';
  static final commondrawer = 'commondrawer';
  static final editprofile = 'editprofile';
  static final notificationmessage = 'notificationmessage';
  static final dashbordmember = 'dashbordmember';
  static final dashbordureadmessagecount = 'dashbordureadmessagecount';
  static final dashbordAnnouncement = 'dashbordAnnouncement';
}
